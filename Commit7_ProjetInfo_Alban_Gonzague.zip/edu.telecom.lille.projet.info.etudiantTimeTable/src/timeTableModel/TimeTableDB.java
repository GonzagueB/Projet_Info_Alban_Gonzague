package timeTableModel;

import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import org.jdom2.Element;
import utils.XMLToFileSaver;
import utils.XMLUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
/**
 * 
 * Cette classe gére la base de données d'emplois du temps. Elle doit permettre de sauvegarder et charger les emplois du temps ainsi que les salles à partir d'un fichier XML. 
 * La structure du fichier XML devra être la même que celle du fichier TimeTableDB.xml.
 * @see <a href="../../TimeTableDB.xml">TimeTableDB.xml</a> 
 * 
 * @author Jose Mennesson (Mettre à jour)
 * @version 04/2016 (Mettre à jour)
 * 
 */

//TODO Classe à modifier

public class TimeTableDB {
	/**
	 * 
	 * Le fichier contenant la base de données.
	 * 
	 */
	
	private String file = null;

    private Hashtable<Integer, Salle> salles = new Hashtable<>();
    private Hashtable<Integer, TimeTable> TimeTables = new Hashtable<>();
    
    private TimeTableDB TimeTableDB = new TimeTableDB(file);
    private SavedState hashLastCommit = null;

	/**
	 * 
	 * Constructeur de TimeTableDB. 
	 * 
	 * @param file
	 * 		Le nom du fichier qui contient la base de donn�es.
	 */
	public TimeTableDB(String file){
		super();
		this.setFile(file);
	}
	
	public static String[] idKeysToStringArray(Hashtable<Integer, ?> in) {
        int size = in.size();
        String[] str = new String[size];
        Enumeration<Integer> keys = in.keys();
        for(Integer i = 0, k = 0; keys.hasMoreElements(); i++, k = keys.nextElement()) {
            str[i] = k.toString();
        }
        return str;
    }
	
	/**
	 * Getter de file
	 * 
	 * @return 
	 * 		Le nom du fichier qui contient la base de donn�es.
	 */
	public String getFile() {
		return file;
	}
	/**
	 * Setter de file
	 * 
	 * @param file
	 * 		Le nom du fichier qui contient la base de donn�es.
	 */
	public void setFile(String file) {
		this.file = file;
		setFile(file);
	}
	
	public boolean saveDB(String file) {
        setFile(file);
        return save(salles, TimeTables, hashLastCommit);
    }
	
	public boolean saveDB() {
        return saveDB(file);
    }
	
	public boolean loadDB() {
        SavedState ss = load(salles, TimeTables);
        this.hashLastCommit = ss;
        return ss != null;
    }
	
	public boolean AddSalle(int SalleID, int NbPlaces) {
        if(salles.containsKey(SalleID))
            return false;
        salles.put(SalleID, new Salle(SalleID, NbPlaces));
		return true;
	}
	
	public int getSalleID(int TimeTableID, int NumeroResa) {
        return TimeTables.get(TimeTableID).getSalle(NumeroResa);
    }
	
	public boolean DeleteSalle(int SalleID) {
        return salles.remove(SalleID) != null;
	}
	
	public String[] roomsIdToString() {
        return TimeTableDB.idKeysToStringArray(salles);
    }
	
	public String[] roomsToString() {
        Enumeration<Integer> keys = salles.keys();
        String[] out = new String[salles.size()];
        for(Integer i = 0, k = 0; keys.hasMoreElements(); i++, k = keys.nextElement()) {
            out[i] = salles.get(k).getData();
        }
        return out;
    }
	
	public boolean addTimeTable(int TimeTableID) {
        if(TimeTables.containsKey(TimeTableID))
            return false;
        TimeTables.put(TimeTableID, new TimeTable(TimeTableID));
        return true;
    }
	
	public boolean removeTimeTable(int TimeTableID) {
        return TimeTables.remove(TimeTableID) != null;
    }

    public String[] timeTablesIDToString() {
        return TimeTableDB.idKeysToStringArray(TimeTables);
    }
    
    public boolean AddReservation(int TimeTableID, int NumeroResa, String LoginProf, Date DateDebut, Date DateFin, int SalleID) {
        Salle salle = salles.get(SalleID);
        TimeTable tt = TimeTables.get(TimeTableID);
        if(tt == null || salle == null)
            return false;
        return tt.AddReservation(NumeroResa, LoginProf, DateDebut, DateFin, salle);
    }
    
    public boolean DeleteReservation(int TimeTableId, int NumeroResa) {
        return TimeTables.remove(TimeTableId) != null;
    }
    
    public void getBookingsDate(int TimeTableID, Hashtable<Integer, Date> DateDebut, Hashtable<Integer, Date> DateFin) {
        TimeTable tt = TimeTables.get(TimeTableID);
        if(tt == null)
            return;
        tt.getBookingsDate(DateDebut, DateFin);
    }
    
    public int getBookingsMaxId(int TimeTableId) {
        TimeTable tt = TimeTables.get(TimeTableId);
        if(tt == null)
            return 0; 
        return tt.getBookingsMaxId();
    }
    
    public String getLoginProf(int TimeTableID, int NumeroResa) {
        TimeTable tt = TimeTables.get(TimeTableID);
        if(tt == null)
            return null;
        return tt.getLoginProf(NumeroResa);
    }
    
    public String[] booksIdToString(int TimeTableId) {
        TimeTable tt = TimeTables.get(TimeTableId);
        if(tt == null)
            return null;
        return tt.idToString();
    }
    
    // Gestion de Load et Save

    public final String
            ROOMS_NAME           = "Salles",
            TIMETABLES_NAME      = "TimesTables",

            LAST_COMMIT          = "LastCommit",
            COMMIT_HASH          = "Hash",
            COMMIT_DATE          = "Date",
            DATE_FORMAT          = "DD/MM/YYYY hh:mm:ss";
    
    public class SavedState {
        private String filePath, hash;
        public SavedState(String filePath, String hash) {
            this.filePath = filePath;
            this.hash = hash;
        }
        @Override
        public boolean equals(Object o) {
            if(!(o instanceof SavedState))
                return false;
            return filePath.equals(((SavedState) o).filePath) &&
                    hash.equals(((SavedState) o).hash);
        }
        public String getFilePath() {
            return filePath;
        }
        public String getHash() {
            return hash;
        }
    }

    public boolean save(Hashtable<Integer, Salle> salles, Hashtable<Integer, TimeTable> TimeTables, SavedState ssAncien) {
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);
        String date = df.format(new Date());
        String hash = XMLUtils.md5(System.currentTimeMillis() + date);
        Element e = new Element(LAST_COMMIT),
                ch = new Element(COMMIT_HASH),
                cd = new Element(COMMIT_DATE);
        cd.setText(date);
        ch.setText(hash);
        e.addContent(ch);
        e.addContent(cd);

        XMLToFileSaver out = new XMLToFileSaver(file);
        Element old = out.loadFromFile();
        Element dom = domBuild(salles, TimeTables);
        dom.addContent(e);

        boolean b = false;
        if(file != null && ssAncien != null && file.equals(ssAncien.getFilePath())) {
            SavedState ss = getLastCommit(old);
            if(!ss.getHash().equals(ssAncien.getHash())) {
                b = true;
            }
        }

        if(b) {
            System.out.println("Ecraser le fichier précédent.");
            System.out.println("Oui (O) ou Non (N) ?");
            Scanner scan = new Scanner(System.in);
            String inStr = scan.nextLine();
            Character c = Character.toUpperCase(inStr.charAt(0));
            if(c == '0') {
                System.out.println("Le fichier va être écrasé.");
                return out.saveToFile(dom);
            }
            else {
                System.out.println("Le fichier n'a pas été enregistré.");
                return false;
            }
        }
        else {
            return out.saveToFile(dom);
        }
    }
    
    public SavedState load(Hashtable<Integer, Salle> salles, Hashtable<Integer, TimeTable> TimeTables) {
        System.out.println(file);
        XMLToFileSaver in = new XMLToFileSaver(file);
        Element e = in.loadFromFile();
        SavedState ss = getLastCommit(e);

        boolean b = decodeElements(e, salles, TimeTables);
        return b ? ss : null;
    }
    
    protected SavedState getLastCommit() {
        return getLastCommit(null);
    }
    protected SavedState getLastCommit(Element e) {
        if(e == null) {
            XMLToFileSaver in = new XMLToFileSaver(file);
            e = in.loadFromFile();
        }
        if(e == null) return null;
        Element commit = e.getChild(LAST_COMMIT);
        SavedState ss = new SavedState(file, commit.getChildText(COMMIT_HASH));
        return ss;
    }

    private Element domBuild(Hashtable<Integer, Salle> salles, Hashtable<Integer, TimeTable> TimeTables) {
        Element root = new Element("TimeTableDB");
        root.addContent(XMLUtils.getXMLFromHashTable(ROOMS_NAME, salles))
                .addContent(XMLUtils.getXMLFromHashTable(TIMETABLES_NAME, TimeTables));
        return root;
    }

    private boolean decodeElements(Element e, Hashtable<Integer, Salle> salles, Hashtable<Integer, TimeTable> TimeTables) {
        if(e == null)
            return false;
        boolean b = false;
        Salle s = new Salle();
        salles.clear();
        TimeTables.clear();
        b = XMLUtils.getFromElement(e.getChild(ROOMS_NAME), salles, new Salle());
        if(!b) return false;
        b = XMLUtils.getFromElement(e.getChild(TIMETABLES_NAME), TimeTables, new TimeTable(), salles);
        if(!b) return false;

        return b;
    }
    
    
    
    
}
