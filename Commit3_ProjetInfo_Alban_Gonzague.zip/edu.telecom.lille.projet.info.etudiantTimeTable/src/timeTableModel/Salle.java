/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package timeTableModel;

import org.jdom2.Element;
import utils.XMLUtils;

/**
 * Description of Salle.
 * 
 * @author gbarois
 */
public class Salle implements XMLUtils.XMLSerializable {
	
	/**
	 * Description of the property NbPlaces.
	 */
	private int NbPlaces;
	
	/**
	 * Description of the property SalleID.
	 */
	private int SalleID;

	public Salle(int roomId, int NbPlaces) {
		this.SalleID = roomId;
		this.NbPlaces = NbPlaces;
	}
	
	Salle() {
        this(-1, 0);
    }
	
	/**
	 * Returns NbPlaces.
	 * @return NbPlaces 
	 */
	public int getNbPlaces() {
		return NbPlaces;
	}

	/**
	 * Sets a value to attribute NbPlaces. 
	 * @param newNbPlaces 
	 */
	public void setNbPlaces(int newNbPlaces) {
		this.NbPlaces = newNbPlaces;
	}

	/**
	 * Returns SalleID.
	 * @return SalleID 
	 */
	public int getSalleID() {
		return SalleID;
	}

	/**
	 * Returns SalleID & NbPlaces
	 */
	public String getData() {
		return SalleID + ";" + NbPlaces;
	}
	
	public Element getXMLElement() {
        Element e = new Element(getXML_NAME()),
                rid = new Element(getXML_INNER_ID()),
                rcp = new Element("Capacity");
        rid.setText("" + SalleID);
        rcp.setText("" + NbPlaces);
        e.addContent(rid);
        e.addContent(rcp);
        return e;
    }
	
	public Salle createFromXMLElement(Element e, Object params) {
        Integer a, b;

        try {
            a = Integer.parseInt(e.getChildText(getXML_INNER_ID()));
            b = Integer.parseInt(e.getChildText("Capacity"));
        }
        catch(NumberFormatException exc) {
            exc.printStackTrace();
            return null;
        }

        return new Salle(a, b);
    }
	
	@Override
    public String getXML_NAME() { return "Salle"; }

    @Override
    public String getXML_INNER_ID() { return "SalleID"; }
}
