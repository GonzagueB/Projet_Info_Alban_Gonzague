/*******************************************************************************
 * 2016, All rights reserved.
 *******************************************************************************/
package timeTableModel;

import org.jdom2.Element;
import utils.XMLUtils;

import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

/**
 * Description of TimeTable.
 * 
 * Class qui permet de g�rer les emplois du temps
 * Ajout ou suppression de r�servation
 * 
 * @author gbarois
 */
public class TimeTable implements XMLUtils.XMLSerializable{
	
	private int TimeTableID;
	private Hashtable<Integer, Reservation> Reservations = new Hashtable<>();

	private static final String
    XML_NAME        = "TimeTable",
    XML_INNER_ID    = "TimeTableID";
	
	/**
	 * Si le num�ro de r�servation n'est pas nul on cr�e la r�servation
	 * @param NumeroResa
	 * @param Reservations
	 */
	TimeTable(int NumeroResa, Hashtable<Integer, Reservation> Reservations) {
        this.TimeTableID = NumeroResa;
        if(Reservations != null)
            this.Reservations = Reservations;
    }
	
	public TimeTable(int NumeroResa) {
        this(NumeroResa, null);
    }
	
	TimeTable() {
        this(-1);
    }
	
	public boolean AddReservation(int NumeroResa, String LoginProf, Date DateDebut, Date DateFin, Salle salle) {
        if(Reservations.containsKey(NumeroResa))
            return false;
        Reservations.put(NumeroResa, new Reservation(NumeroResa, salle, LoginProf, DateDebut, DateFin));
        return true;
    }
	
	public boolean DeleteReservation(int NumeroResa) {
        return Reservations.remove(NumeroResa) != null;
    }
	
	public int getSalle(int SalleID) {
        return Reservations.get(SalleID).getSalle().getSalleID();
    }
	
	public void getBookingsDate(Hashtable<Integer, Date> DateDebut, Hashtable<Integer, Date> DateFin) {
        Enumeration<Integer> keys = Reservations.keys();
        int v;
        Reservation b;
        while(keys.hasMoreElements()) {
            v = keys.nextElement();
            b = Reservations.get(v);
            DateDebut.put(v, b.getDateDebut());
            DateFin.put(v, b.getDateFin());
        }
    }

	public int getBookingsMaxId() {
        Enumeration<Integer> keys = Reservations.keys();
        int max = 0, v;
        while(keys.hasMoreElements()) {
            v = keys.nextElement();
            if(v > max)
                max = v;
        }
        return max;
    }
	
	public String getLoginProf(int bookId) {
        Reservation book = Reservations.get(bookId);
        if(book == null)
            return null;
        return book.getLoginProf();
    }
	
	public String[] idToString() {
        return TimeTableDB.idKeysToStringArray(Reservations);
    }
	
	@Override
    public Element getXMLElement() {
        Element e = new Element(XML_NAME);

        Element gid = new Element(XML_INNER_ID);
        gid.setText("" + TimeTableID);
        e.addContent(gid);

        e.addContent(XMLUtils.getXMLFromHashTable("Reservations", Reservations));

        return e;
    }
	
	@Override
    public String getXML_NAME() {
        return XML_NAME;
    }

    @Override
    public String getXML_INNER_ID() {
        return XML_INNER_ID;
    }
    
    public TimeTable createFromXMLElement(Element e, Object params) {
        Hashtable<Integer, Salle> salles = (Hashtable<Integer, Salle>) params;
        Integer TimeTableID = Integer.parseInt(e.getChildText(XML_INNER_ID));
        Hashtable<Integer, Reservation> Reservations = new Hashtable<>();
        boolean b = XMLUtils.getFromElement(e.getChild("Reservations"), Reservations, new Reservation(), salles);
        if(!b) return null;
        return new TimeTable(TimeTableID, Reservations);
    }

}
