package timeTableModel;

import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
/**
 * 
 * Cette classe gére la base de données d'emplois du temps. Elle doit permettre de sauvegarder et charger les emplois du temps ainsi que les salles à partir d'un fichier XML. 
 * La structure du fichier XML devra être la même que celle du fichier TimeTableDB.xml.
 * @see <a href="../../TimeTableDB.xml">TimeTableDB.xml</a> 
 * 
 * @author Jose Mennesson (Mettre à jour)
 * @version 04/2016 (Mettre à jour)
 * 
 */

//TODO Classe à modifier

public class TimeTableDB {
	/**
	 * 
	 * Le fichier contenant la base de données.
	 * 
	 */
	
	private String file = null;

    private Hashtable<Integer, Salle> salles = new Hashtable<>();
    private Hashtable<Integer, TimeTable> TimeTables = new Hashtable<>();

	/**
	 * 
	 * Constructeur de TimeTableDB. 
	 * 
	 * @param file
	 * 		Le nom du fichier qui contient la base de données.
	 */
	public TimeTableDB(String file){
		super();
		this.setFile(file);
	}
	
	public static String[] idKeysToStringArray(Hashtable<Integer, ?> in) {
        int size = in.size();
        String[] str = new String[size];
        Enumeration<Integer> keys = in.keys();
        for(Integer i = 0, k = 0; keys.hasMoreElements(); i++, k = keys.nextElement()) {
            str[i] = k.toString();
        }
        return str;
    }
	
	/**
	 * Getter de file
	 * 
	 * @return 
	 * 		Le nom du fichier qui contient la base de données.
	 */
	public String getFile() {
		return file;
	}
	/**
	 * Setter de file
	 * 
	 * @param file
	 * 		Le nom du fichier qui contient la base de données.
	 */
	public void setFile(String file) {
		this.file = file;
	}
	
	/*public boolean saveDB(String file) {
        return saveDB(file);
    }
	
	public boolean loadDB(String file) {
		return loadDB(file);
	}*/
	
	public boolean AddSalle(int SalleID, int NbPlaces) {
        if(salles.containsKey(SalleID))
            return false;
        salles.put(SalleID, new Salle(SalleID, NbPlaces));
		return true;
	}
	
	public int getSalleID(int TimeTableID, int NumeroResa) {
        return TimeTables.get(TimeTableID).getSalle(NumeroResa);
    }
	
	public boolean DeleteSalle(int SalleID) {
        return salles.remove(SalleID) != null;
	}
	
	public String[] roomsIdToString() {
        return TimeTableDB.idKeysToStringArray(salles);
    }
	
	public String[] roomsToString() {
        Enumeration<Integer> keys = salles.keys();
        String[] out = new String[salles.size()];
        for(Integer i = 0, k = 0; keys.hasMoreElements(); i++, k = keys.nextElement()) {
            out[i] = salles.get(k).getData();
        }
        return out;
    }
	
	public boolean addTimeTable(int TimeTableID) {
        if(TimeTables.containsKey(TimeTableID))
            return false;
        TimeTables.put(TimeTableID, new TimeTable(TimeTableID));
        return true;
    }
	
	public boolean removeTimeTable(int TimeTableID) {
        return TimeTables.remove(TimeTableID) != null;
    }

    public String[] timeTablesIDToString() {
        return TimeTableDB.idKeysToStringArray(TimeTables);
    }
    
    public boolean AddReservation(int TimeTableID, int NumeroResa, String LoginProf, Date DateDebut, Date DateFin, int SalleID) {
        Salle salle = salles.get(SalleID);
        TimeTable tt = TimeTables.get(TimeTableID);
        if(tt == null || salle == null)
            return false;
        return tt.AddReservation(NumeroResa, LoginProf, DateDebut, DateFin, salle);
    }
    
    public boolean DeleteReservation(int TimeTableId, int NumeroResa) {
        return TimeTables.remove(TimeTableId) != null;
    }
    
    public void getBookingsDate(int TimeTableID, Hashtable<Integer, Date> DateDebut, Hashtable<Integer, Date> DateFin) {
        TimeTable tt = TimeTables.get(TimeTableID);
        if(tt == null)
            return;
        tt.getBookingsDate(DateDebut, DateFin);
    }
    
    public int getBookingsMaxId(int TimeTableId) {
        TimeTable tt = TimeTables.get(TimeTableId);
        if(tt == null)
            return 0; 
        return tt.getBookingsMaxId();
    }
    
    public String getLoginProf(int TimeTableID, int NumeroResa) {
        TimeTable tt = TimeTables.get(TimeTableID);
        if(tt == null)
            return null;
        return tt.getLoginProf(NumeroResa);
    }
    
    public String[] booksIdToString(int TimeTableId) {
        TimeTable tt = TimeTables.get(TimeTableId);
        if(tt == null)
            return null;
        return tt.idToString();
    }
}
