package timeTableModel;

import org.jdom2.Element;
import utils.XMLUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

public class Reservation implements XMLUtils.XMLSerializable {

    private static final String
            XML_NAME        = "Book",
            XML_INNER_ID    = "BookingId";

    private static final String
        LOGIN_PROF       = "LoginProf",
        DATE_DEBUT  = "DateDebut",
        DATE_FIN    = "DateFin",
        SALLE_ID     = "SalleId",
        DATE_FORMAT = "DD/MM/YYYY hh:mm:ss"
    ;

    private int SalleID;
    private Salle salle;
    private String LoginProf;
    private Date DateDebut, DateFin;

    public Reservation(int NumeroResa, Salle salle, String LoginProf,Date DateDebut, Date DateFin) {
        this.SalleID = NumeroResa;
        this.salle = salle;
        this.LoginProf = LoginProf;
        this.DateDebut = DateDebut;
        this.DateFin = DateFin;
    }

    Reservation() {
        this(-1, null, null, null, null);
    }

    public int getSalleID() {
        return SalleID;
    }

    public Salle getSalle() {
        return salle;
    }

    public String getLoginProf() {
        return LoginProf;
    }

    public Date getDateDebut() {
        return DateDebut;
    }

    public Date getDateFin() {
        return DateFin;
    }


    @Override
    public Element getXMLElement() {
        Element e = new Element(XML_NAME);
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);

        Element bid = new Element(XML_INNER_ID);
        bid.setText("" + SalleID);
        e.addContent(bid);

        Element login = new Element(LOGIN_PROF);
        login.setText(LoginProf);
        e.addContent(login);

        Element dDebut = new Element(DATE_DEBUT);
        dDebut.setText(df.format(DateDebut));
        e.addContent(dDebut);

        Element dFin = new Element(DATE_FIN);
        dFin.setText(df.format(DateFin));
        e.addContent(dFin);

        Element rid = new Element(SALLE_ID);
        rid.setText("" + salle.getSalleID());
        e.addContent(rid);

        return e;
    }

    @Override
    public String getXML_NAME() {
        return XML_NAME;
    }

    @Override
    public String getXML_INNER_ID() {
        return XML_INNER_ID;
    }

    public Reservation createFromXMLElement(Element e, Object params) {
        if(params == null)
            return null;
        Hashtable<Integer, Salle> salles = (Hashtable<Integer, Salle>) params;
        DateFormat df = new SimpleDateFormat(DATE_FORMAT);

        Date db, de;
        try {
            db = df.parse(e.getChildText(DATE_DEBUT));
            de = df.parse(e.getChildText(DATE_FIN));
        } catch (ParseException e1) {
            e1.printStackTrace();
            return null;
        }

        return new Reservation(
            Integer.parseInt(e.getChildText(XML_INNER_ID)),
            salles.get(Integer.parseInt(e.getChildText(SALLE_ID))),
            e.getChildText(LOGIN_PROF),
            db, de
        );
    }

}